"""
test_mediinfo.py - Comprehensive Unit and Integration Test Suite for MediInfo AI.

Tests all 7 required evaluation scenarios:
1. Valid medicine search
2. Case-insensitive search
3. Medicine not found
4. Empty search
5. Missing dataset fields (graceful degradation without fabrication)
6. Gemini API failure handling
7. Multiple matching records
"""

import os
import pytest
import pandas as pd
from unittest.mock import patch, MagicMock

import data_handler
import llm


@pytest.fixture
def dataset_df():
    """Fixture providing loaded medicine dataset."""
    return data_handler.load_dataset("medicine_data.csv")


# --- Test 1: Valid Medicine Search ---
def test_valid_medicine_search(dataset_df):
    """Verify that searching for a valid medicine returns the exact match and full details."""
    result = data_handler.search_medicine("Paracetamol", dataset_df)
    assert result["status"] == "exact_match"
    assert result["count"] == 1
    assert result["primary_match"] is not None

    record = result["primary_match"]
    assert record["medicine_name"] == "Paracetamol"
    assert record["generic_name"] == "Acetaminophen"
    assert "pain" in record["uses"].lower() or "fever" in record["uses"].lower()
    assert len(record["description"]) > 10


# --- Test 2: Case-Insensitive Search & Whitespace Trimming ---
@pytest.mark.parametrize("query,expected_name", [
    ("pArAcEtAmOl", "Paracetamol"),
    ("METFORMIN", "Metformin"),
    ("  amoxicillin   ", "Amoxicillin"),
    ("\tATORVASTATIN\n", "Atorvastatin"),
    ("  cetirizine  ", "Cetirizine"),
])
def test_case_insensitive_and_whitespace_search(dataset_df, query, expected_name):
    """Verify case-insensitivity and tolerance for leading/trailing whitespaces."""
    result = data_handler.search_medicine(query, dataset_df)
    assert result["status"] == "exact_match"
    assert result["primary_match"]["medicine_name"] == expected_name


# --- Test 3: Medicine Not Found ---
def test_medicine_not_found(dataset_df):
    """Verify appropriate response and spelling suggestions when medicine does not exist."""
    result = data_handler.search_medicine("NonExistentDrug999", dataset_df)
    assert result["status"] == "not_found"
    assert result["count"] == 0
    assert result["primary_match"] is None
    assert "Medicine not found in our database" in result["message"]
    assert "spelling" in result["message"]


# --- Test 4: Empty Search Handling ---
@pytest.mark.parametrize("empty_query", ["", "   ", "\t", "\n", None])
def test_empty_search(dataset_df, empty_query):
    """Verify graceful handling when user submits empty or whitespace-only query."""
    result = data_handler.search_medicine(empty_query, dataset_df)
    assert result["status"] == "empty_query"
    assert result["count"] == 0
    assert result["primary_match"] is None
    assert "enter a medicine name" in result["message"].lower()


# --- Test 5: Missing Dataset Fields (No Data Fabrication) ---
def test_missing_dataset_fields(dataset_df):
    """
    Verify that if a field is empty in the dataset, the system explicitly marks
    it as unavailable and never fabricates facts.
    """
    # SimpleCoughSyrup has an empty side_effects field in our CSV
    result_cough = data_handler.search_medicine("SimpleCoughSyrup", dataset_df)
    assert result_cough["status"] == "exact_match"
    record_cough = result_cough["primary_match"]
    assert record_cough["side_effects"] == "Information not available in dataset"

    # ZincSulfateSupplement has an empty precautions field in our CSV
    result_zinc = data_handler.search_medicine("ZincSulfateSupplement", dataset_df)
    assert result_zinc["status"] == "exact_match"
    record_zinc = result_zinc["primary_match"]
    assert record_zinc["precautions"] == "Information not available in dataset"

    # Test format_medicine_record with arbitrary NaN / empty values
    custom_series = pd.Series({
        "medicine_name": "TestDrug",
        "generic_name": None,
        "uses": "",
        "description": "nan",
        "side_effects": "None",
        "precautions": "N/A",
    })
    formatted = data_handler.format_medicine_record(custom_series)
    assert formatted["generic_name"] == "Information not available in dataset"
    assert formatted["uses"] == "Information not available in dataset"
    assert formatted["description"] == "Information not available in dataset"
    assert formatted["side_effects"] == "Information not available in dataset"
    assert formatted["precautions"] == "Information not available in dataset"


# --- Test 6: Gemini API Failure Handling ---
def test_gemini_api_failure_missing_key():
    """Verify that LLM call returns clean failure dict when API key is missing."""
    test_med = {
        "medicine_name": "Paracetamol",
        "generic_name": "Acetaminophen",
        "uses": "Pain relief",
        "description": "Analgesic",
        "side_effects": "Nausea",
        "precautions": "Avoid alcohol",
    }
    # Explicit empty key
    result = llm.generate_explanation(test_med, api_key="")
    assert result["success"] is False
    assert result["error"] is not None
    assert "API key" in result["error"]


def test_gemini_api_network_or_quota_failure():
    """Verify graceful handling when Gemini client throws an exception (e.g. quota/network)."""
    test_med = {"medicine_name": "Paracetamol"}

    with patch("llm.get_client") as mock_get_client:
        mock_client = MagicMock()
        mock_client.models.generate_content.side_effect = Exception("429 Resource Exhausted: Quota exceeded")
        mock_get_client.return_value = mock_client

        result = llm.generate_explanation(test_med, api_key="test_fake_key")
        assert result["success"] is False
        assert "Quota exceeded" in result["error"]
        assert result["explanation"] == ""


# --- Test 7: Multiple Matching Records ---
def test_multiple_matching_records(dataset_df):
    """
    Verify that when multiple medicines match a substring, the system detects
    multiple matches and provides all candidate records for user selection.
    """
    # 'azole' matches Omeprazole and Pantoprazole
    result = data_handler.search_medicine("azole", dataset_df)
    assert result["status"] == "multiple_matches"
    assert result["count"] >= 2
    assert len(result["records"]) >= 2
    matched_names = [r["medicine_name"] for r in result["records"]]
    assert "Omeprazole" in matched_names
    assert "Pantoprazole" in matched_names

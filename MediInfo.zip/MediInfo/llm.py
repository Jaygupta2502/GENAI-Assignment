"""
llm.py - Google Gemini API integration and prompt management for MediInfo AI.

Uses the official Google GenAI Python SDK (google-genai).
Enforces strict medical safety guardrails, plain-English translations of
technical jargon, and ensures the LLM relies solely on dataset facts.
"""

import os
from typing import Any, Dict, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


SYSTEM_PROMPT = """You are MediInfo AI, a compassionate and precise clinical education assistant designed to explain medicine information in simple, clear, patient-friendly English.

STRICT MEDICAL SAFETY & ACCURACY RULES:
1. ONLY USE SUPPLIED INFORMATION: Rely strictly and exclusively on the medicine data provided in the prompt. Do NOT fabricate, extrapolate, or invent unlisted indications, benefits, side effects, or precautions.
2. MISSING INFORMATION: If any field states 'Information not available in dataset' or is empty, explicitly state that this specific information is not available in the database.
3. NEVER PRESCRIBE OR SUGGEST DOSAGES: Do not recommend dosage amounts, frequencies, schedules, or adjustments under any circumstances.
4. NO TREATMENT ALTERATIONS: Never advise the patient to start, stop, increase, decrease, or substitute medications.
5. NO MEDICAL DIAGNOSIS: Never attempt to diagnose symptoms or health conditions.
6. TRANSLATE MEDICAL JARGON: Translate complex clinical terms (e.g., 'antipyretic', 'H1 receptor antagonist', 'bronchospasm', 'hyperkalemia') into plain, everyday language that any non-medical reader can easily understand.
7. FORMATTING: Present your explanation cleanly using clear Markdown headings and organized bullet points.
"""


def get_api_key(explicit_key: Optional[str] = None) -> Optional[str]:
    """
    Retrieve Gemini API key with priority:
    1. Explicit key passed from UI/arguments (if provided, even if empty)
    2. GEMINI_API_KEY from environment / .env file
    """
    if explicit_key is not None:
        cleaned = explicit_key.strip()
        return cleaned if cleaned else None
    env_key = os.getenv("GEMINI_API_KEY")
    if env_key and env_key.strip() and env_key.strip() != "your_gemini_api_key_here":
        return env_key.strip()
    return None


def get_client(api_key: Optional[str] = None):
    """
    Instantiate and return the official Google GenAI Client.
    Raises ValueError if no valid API key is found.
    """
    key = get_api_key(api_key)
    if not key:
        raise ValueError(
            "Gemini API key is not configured. Please add GEMINI_API_KEY to your .env file "
            "or enter it in the application sidebar."
        )

    from google import genai
    return genai.Client(api_key=key)


def build_explanation_prompt(medicine_data: Dict[str, str]) -> str:
    """
    Construct a grounded, structured prompt from dataset fields.
    """
    med_name = medicine_data.get("medicine_name", "Unknown")
    gen_name = medicine_data.get("generic_name", "Information not available in dataset")
    uses = medicine_data.get("uses", "Information not available in dataset")
    desc = medicine_data.get("description", "Information not available in dataset")
    side_effects = medicine_data.get("side_effects", "Information not available in dataset")
    precautions = medicine_data.get("precautions", "Information not available in dataset")

    prompt = f"""Please explain the following medicine to a patient in simple, reassuring English based STRICTLY on this verified database entry:

---
### DATABASE RECORD:
- **Medicine Name**: {med_name}
- **Generic / Active Ingredient**: {gen_name}
- **Description / Classification**: {desc}
- **Uses / Indications**: {uses}
- **Common Side Effects**: {side_effects}
- **Safety Warnings / Precautions**: {precautions}
---

Please structure your response with these exact sections:

### 🌟 1. What is this Medicine and What Does It Do?
(Explain the purpose of this medication in 2-3 simple sentences. Clarify the active ingredient and simplify technical terms.)

### 🎯 2. Why is it Prescribed? (Uses)
(Explain the listed medical uses in bullet points with everyday language.)

### ⚠️ 3. Common Side Effects to Know
(Explain the listed common side effects. Explain what they feel like in simple terms. If side effects were marked as unavailable, explicitly mention that.)

### 🛡️ 4. Important Safety Precautions
(Explain the listed precautions and warnings in clear bullet points. If precautions were marked as unavailable, explicitly mention that.)

### 📖 5. Medical Terms Simplified
(Identify 2-3 complex terms mentioned above and define them simply for a layperson.)

REMINDER: Use only the information above. Do not recommend dosages or medication changes."""
    return prompt


# Primary model as requested: gemini-3.8-flash
PRIMARY_MODEL = "gemini-3.8-flash"

# Model cascade: attempts gemini-3.8-flash first; if experiencing temporary high-demand
# spikes (503) or unavailability (404), cascades to gemini-3.5-flash-lite for instant response.
FALLBACK_MODELS = [
    "gemini-3.8-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.5-flash",
]


def generate_explanation(
    medicine_data: Dict[str, str],
    api_key: Optional[str] = None,
    model: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate an AI-powered plain English explanation for a medicine.
    Uses gemini-3.8-flash as primary model with intelligent fallback to
    ensure uninterrupted service even during API traffic spikes.

    Args:
        medicine_data: Dictionary of medicine fields from data_handler.
        api_key: Optional explicit Gemini API key.
        model: Specific Gemini model identifier or None to use gemini-3.8-flash cascade.

    Returns:
        Dict containing:
            - 'success': bool
            - 'explanation': str (Markdown formatted text if success=True)
            - 'error': str (Error description if success=False)
            - 'model': str
    """
    try:
        from google.genai import types

        client = get_client(api_key=api_key)
        prompt = build_explanation_prompt(medicine_data)

        models_to_try = [model] if model else FALLBACK_MODELS
        last_error = None

        for candidate_model in models_to_try:
            try:
                response = client.models.generate_content(
                    model=candidate_model,
                    contents=prompt,
                    config=types.GenerateContentConfig(
                        system_instruction=SYSTEM_PROMPT,
                        temperature=0.2,  # Low temperature for factual precision
                        http_options=types.HttpOptions(timeout=10000),  # 10s deadline
                    ),
                )
                explanation_text = response.text or "No explanation could be generated."
                return {
                    "success": True,
                    "explanation": explanation_text,
                    "error": None,
                    "model": candidate_model,
                }
            except Exception as model_err:
                last_error = model_err
                err_str = str(model_err)
                # If model is unavailable (503/404/NOT_FOUND), cascade to next candidate
                if any(k in err_str for k in ["404", "503", "NOT_FOUND", "UNAVAILABLE", "ResourceExhausted"]):
                    continue
                else:
                    # Authentication or fatal client error - stop immediately
                    raise model_err

        raise last_error if last_error else RuntimeError("No models available.")

    except ValueError as ve:
        return {
            "success": False,
            "explanation": "",
            "error": str(ve),
            "model": "N/A",
        }
    except Exception as e:
        error_msg = f"Gemini API request failed: {str(e)}"
        return {
            "success": False,
            "explanation": "",
            "error": error_msg,
            "model": "N/A",
        }

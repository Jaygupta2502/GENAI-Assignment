# MediInfo AI – Medicine Information Lookup

**Problem Statement:** PS 58 – Medicine Information Lookup  
**Target:** Final-Year B.Tech Computer Science Mini-Project Evaluation (10 Marks)  
**Technology Stack:** Python 3.12, Streamlit, Pandas, Google Gemini API (`google-genai`), Python Dotenv, Pytest

---

## 📌 Executive Summary

**MediInfo AI** is an intelligent, accessible healthcare information web application engineered to bridge the communication gap between complex pharmacological literature and patients. Utilizing a verified medicine dataset and Google Gemini LLM API via the official **Google GenAI Python SDK**, the application allows users to search for medications and receive structured dataset records accompanied by patient-friendly, plain-English explanations with strict medical safety guardrails.

---

## 🌟 Key Features

1. **Intelligent Medicine Search**:
   - Case-insensitive searching (e.g. `pArAcEtAmOl` matches `Paracetamol`).
   - Whitespace trimming and normalization.
   - Dual-field matching: matches against both commercial brand names and active generic chemical names.
   - Exact match prioritization with substring fallback and multi-match selection.
   - "Medicine not found in our database" message with spelling suggestions.

2. **Verified Structured Information Display**:
   - Medicine Name
   - Generic Name (Active Chemical Compound)
   - Uses & Medical Indications
   - Description & Pharmacological Mechanism
   - Common Known Side Effects
   - Safety Precautions & Warnings
   - Strict factual integrity: missing fields are explicitly indicated as unavailable and **never fabricated**.

3. **AI-Powered Patient-Friendly Translation**:
   - Integrates Google Gemini API using the official `google-genai` SDK.
   - Converts clinical jargon (e.g., *antipyretic*, *H1 receptor antagonist*, *bronchospasm*) into everyday, reassuring language.
   - Grounded strictly in the retrieved dataset fields.

4. **Strict Medical Safety Guardrails**:
   - Prominent medical disclaimer on every screen.
   - Clear visual differentiation between verified dataset facts and AI explanations.
   - Explicit system prompt instructions forbidding dosage recommendations, treatment changes, or clinical diagnoses.

5. **Healthcare Dashboard UI**:
   - Built with Streamlit featuring a white and light-blue clinical theme (`#0284c7`, `#0ea5e9`, `#f0f9ff`).
   - Responsive rounded cards with subtle drop shadows.
   - Interactive Medicine Directory catalog tab.
   - Quick sample search chips for one-click evaluation testing.

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    User([👤 User / Patient]) -->|Enter Search Query| UI[🌐 Streamlit Web UI: app.py]
    UI -->|Normalized Query| DH[⚙️ Data Handler: data_handler.py]
    DH -->|Query Filter| CSV[(📁 Verified Dataset: medicine_data.csv)]
    CSV -->|Retrieved Records| DH
    DH -->|Structured Records| UI
    
    alt Medicine Found (Exact or Selected)
        UI -->|Render Verified Cards| Screen1[📋 Dataset Information Cards]
        UI -->|Click 'Explain in Simple English'| LLM[🤖 LLM Engine: llm.py]
        LLM -->|Grounded Prompt with Safety Instructions| Gemini[☁️ Google Gemini API]
        Gemini -->|Plain English Markdown| LLM
        LLM -->|Formatted Explanation| Screen2[✨ Patient-Friendly AI Card]
    else Medicine Not Found
        UI -->|Display 'Medicine not found'| ErrMsg[⚠️ Not Found + Spelling Suggestions]
    end
```

---

## 📂 Project Structure

```
MediInfo/
│
├── app.py                 # Streamlit web user interface and healthcare dashboard
├── data_handler.py        # Dataset loading, data cleaning, and medicine search logic
├── llm.py                 # Google Gemini API integration (official google-genai SDK)
├── medicine_data.csv      # Curated, verified medicine dataset with 24 essential medicines
├── test_mediinfo.py       # Automated unit & integration test suite (Pytest)
├── generate_report.py     # Academic 4-page PDF and DOCX procedure report generator
├── requirements.txt       # Project dependencies
├── .env.example           # Example environment variable configuration
├── .gitignore             # Git ignore file for secrets and virtual environments
├── README.md              # Academic documentation and evaluation guide
└── submission/            # College mini-project submission deliverables
    ├── MediInfo_AI_PS58_Procedure_Report.pdf   # Exactly 4-page verified PDF
    └── MediInfo_AI_PS58_Procedure_Report.docx  # Editable Word document
```

---

## 📊 Dataset Schema

The application uses `medicine_data.csv` containing essential medications across diverse therapeutic categories (Analgesics, Antibiotics, Antidiabetics, Antihypertensives, Antihistamines, Proton Pump Inhibitors, Respiratory Agents, SSRIs, Corticosteroids).

| Column Name | Type | Description | Example |
|---|---|---|---|
| `medicine_name` | String | Common or brand name | `Paracetamol` |
| `generic_name` | String | Active pharmaceutical ingredient | `Acetaminophen` |
| `uses` | String | Medical indications and conditions | `Relief of mild to moderate pain...` |
| `description` | String | Pharmacological mechanism and category | `Non-opioid analgesic and antipyretic...` |
| `side_effects` | String | Known common adverse effects | `Nausea, allergic skin rash...` |
| `precautions` | String | Warnings, interactions, and lifestyle care | `Avoid consuming alcohol; max 4000 mg...` |

---

## 🚀 Setup & Installation Instructions

### Prerequisites
- Python 3.10+ (Tested on Python 3.12)
- Google Gemini API Key ([Get a free key from Google AI Studio](https://aistudio.google.com/))

### 1. Clone or Open the Repository
```bash
cd MediInfo
```

### 2. (Optional) Create and Activate a Virtual Environment
```bash
python -m venv venv
# Windows:
.\venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure Environment Variables
Copy `.env.example` to `.env` and insert your Gemini API Key:
```bash
cp .env.example .env
```
Inside `.env`:
```env
GEMINI_API_KEY=your_actual_gemini_api_key_here
```
*(Note: You can also enter the API key directly in the Streamlit sidebar at runtime.)*

### 5. Launch the Web Application
```bash
python -m streamlit run app.py
```
*(Or `streamlit run app.py` if Python's Scripts directory is on your PATH)*
Open your browser at `http://localhost:8501`.

---

## 🧪 Automated Testing

The project includes an automated test suite in `test_mediinfo.py` covering all 7 evaluation scenarios required by the problem statement:

1. **Valid Medicine Search**: Exact match retrieval with full field verification.
2. **Case-Insensitive Search**: Matches mixed case inputs like `pArAcEtAmOl` and `METFORMIN`.
3. **Medicine Not Found**: Verifies "Medicine not found in our database" message and spelling suggestion.
4. **Empty Search**: Graceful handling of empty or whitespace queries without exceptions.
5. **Missing Dataset Fields**: Ensures missing fields degrade to `"Information not available in dataset"` without fabricating facts.
6. **Gemini API Failure Handling**: Verifies graceful error messages on missing or invalid keys, and network/quota timeouts.
7. **Multiple Matching Records**: Verifies detection and candidate listing when multiple medicines match a substring (e.g. `azole`).

### Run the Tests:
```bash
python -m pytest test_mediinfo.py -v
```
**Test Results:**
```
======================== 16 passed, 1 warning in 2.27s ========================
```

---

## 🛡️ Medical Safety & Ethical Compliance

- **Mandatory Disclaimer**:  
  > *"This application provides educational information only. It does not provide medical advice, diagnosis or treatment recommendations. Always consult a qualified healthcare professional."*
- **No Dosage Prescriptions**: The AI prompt strictly prohibits providing dosages or scheduling instructions to prevent accidental overdose or self-medication.
- **Zero Fabrication**: If a field is empty in the dataset, the system explicitly reports it as unavailable.
- **Clear Information Lineage**: Raw database records and AI explanations are visually and semantically distinct.

---

## 🎓 University Evaluation Rubric (10 Marks)

| Evaluation Parameter | Marks | Implementation in MediInfo AI |
|---|:---:|---|
| **Problem Formulation & Architecture** | 2 | Clean modular architecture (`app.py`, `data_handler.py`, `llm.py`, `medicine_data.csv`) |
| **Data Handling & Search Algorithm** | 2 | Case-insensitive Pandas search, whitespace handling, exact vs substring match hierarchy |
| **LLM Integration & Prompt Engineering** | 2 | Official Google GenAI SDK (`google-genai`), system instruction safety guardrails |
| **UI/UX & Healthcare Dashboard Design** | 2 | Streamlit white & light-blue theme, responsive cards, quick search chips, catalog table |
| **Testing, Security & Code Quality** | 2 | 16/16 pytest passing test cases, `.env` key isolation, zero hardcoded secrets |

---

## 📄 License
Educational and research use only under the MIT License.

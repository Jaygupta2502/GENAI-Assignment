"""
data_handler.py - Data ingestion, cleaning, and search operations for MediInfo AI.

Handles loading of the medicine CSV dataset, sanitization, case-insensitive
matching, whitespace trimming, and missing field handling without fabrication.
"""

import os
from typing import Any, Dict, List, Optional, Tuple
import pandas as pd


# Expected standard columns for the medicine dataset
EXPECTED_COLUMNS = [
    "medicine_name",
    "generic_name",
    "uses",
    "description",
    "side_effects",
    "precautions",
]


def load_dataset(filepath: str = "medicine_data.csv") -> pd.DataFrame:
    """
    Load and sanitize the medicine dataset from a CSV file.

    Args:
        filepath: Relative or absolute path to the CSV file.

    Returns:
        pd.DataFrame: Cleaned and structured medicine dataframe.

    Raises:
        FileNotFoundError: If the specified CSV file does not exist.
        ValueError: If required columns are missing.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Dataset file '{filepath}' was not found.")

    df = pd.read_csv(filepath, encoding="utf-8")

    # Normalize column names: lowercase and stripped
    df.columns = [col.strip().lower() for col in df.columns]

    # Check for core required identifier column
    if "medicine_name" not in df.columns:
        raise ValueError(
            "Dataset must contain at least a 'medicine_name' column."
        )

    # Ensure all expected columns exist in dataframe (fill missing columns with empty strings)
    for col in EXPECTED_COLUMNS:
        if col not in df.columns:
            df[col] = ""

    # Clean text columns: fill NaN with empty string and strip whitespace
    for col in df.columns:
        if df[col].dtype == object or isinstance(df[col].dtype, pd.StringDtype):
            df[col] = df[col].fillna("").astype(str).str.strip()

    return df


def clean_query(query: Optional[str]) -> str:
    """
    Sanitize and normalize user search query.
    Handles minor whitespace differences, leading/trailing spaces, and casing.
    """
    if query is None:
        return ""
    # Strip spaces and normalize internal whitespace
    cleaned = " ".join(str(query).strip().split())
    return cleaned


def search_medicine(
    query: str, df: pd.DataFrame
) -> Dict[str, Any]:
    """
    Search the medicine dataset for matching records.
    Supports case-insensitive searching, whitespace normalization,
    and searching across medicine_name and generic_name fields.

    Args:
        query: User entered search string.
        df: Loaded medicine pandas DataFrame.

    Returns:
        Dict containing:
            - 'status': 'empty_query' | 'exact_match' | 'multiple_matches' | 'not_found'
            - 'message': User-friendly description or suggestions
            - 'count': Number of matching records
            - 'records': List of dictionary representations of matching medicines
            - 'primary_match': Single dictionary if exact/single match found, else None
    """
    cleaned = clean_query(query)

    if not cleaned:
        return {
            "status": "empty_query",
            "message": "Please enter a medicine name to search.",
            "count": 0,
            "records": [],
            "primary_match": None,
        }

    q_lower = cleaned.lower()

    # Priority 1: Exact match on medicine_name (case-insensitive)
    exact_name_mask = df["medicine_name"].str.lower() == q_lower
    # Priority 2: Exact match on generic_name (case-insensitive)
    exact_generic_mask = df["generic_name"].str.lower() == q_lower

    exact_mask = exact_name_mask | exact_generic_mask
    exact_matches = df[exact_mask]

    if len(exact_matches) == 1:
        record = format_medicine_record(exact_matches.iloc[0])
        return {
            "status": "exact_match",
            "message": f"Exact match found for '{cleaned}'.",
            "count": 1,
            "records": [record],
            "primary_match": record,
        }

    # Priority 3: Substring / Partial match on medicine_name or generic_name
    sub_name_mask = df["medicine_name"].str.lower().str.contains(q_lower, regex=False)
    sub_generic_mask = df["generic_name"].str.lower().str.contains(q_lower, regex=False)
    partial_matches = df[sub_name_mask | sub_generic_mask]

    if len(partial_matches) == 1:
        record = format_medicine_record(partial_matches.iloc[0])
        return {
            "status": "exact_match",
            "message": f"Match found for '{cleaned}'.",
            "count": 1,
            "records": [record],
            "primary_match": record,
        }
    elif len(partial_matches) > 1:
        records = [format_medicine_record(row) for _, row in partial_matches.iterrows()]
        names = [r["medicine_name"] for r in records]
        return {
            "status": "multiple_matches",
            "message": f"Multiple medicines match '{cleaned}'. Please select one from the options below: {', '.join(names[:5])}",
            "count": len(records),
            "records": records,
            "primary_match": records[0],
        }

    # No matches found: suggest available medicines or spelling check
    all_names = df["medicine_name"].tolist()
    # Simple prefix or 3-letter similarity suggestion
    suggestions = [
        name for name in all_names
        if name.lower().startswith(q_lower[:3]) or q_lower[:3] in name.lower()
    ] if len(q_lower) >= 3 else []

    msg = "Medicine not found in our database. Please check the spelling."
    if suggestions:
        msg += f" Did you mean: {', '.join(suggestions[:3])}?"

    return {
        "status": "not_found",
        "message": msg,
        "count": 0,
        "records": [],
        "primary_match": None,
    }


def format_medicine_record(row: pd.Series) -> Dict[str, str]:
    """
    Format a single row from the DataFrame into a clean dictionary.
    Guarantees that missing or empty fields are explicitly marked as unavailable
    and never fabricated.
    """
    def sanitize_field(value: Any) -> str:
        if pd.isna(value) or value is None:
            return "Information not available in dataset"
        val_str = str(value).strip()
        if not val_str or val_str.lower() in ["nan", "none", "null", "n/a", "na"]:
            return "Information not available in dataset"
        return val_str

    return {
        "medicine_name": sanitize_field(row.get("medicine_name")),
        "generic_name": sanitize_field(row.get("generic_name")),
        "uses": sanitize_field(row.get("uses")),
        "description": sanitize_field(row.get("description")),
        "side_effects": sanitize_field(row.get("side_effects")),
        "precautions": sanitize_field(row.get("precautions")),
    }


def get_all_medicines_summary(df: pd.DataFrame) -> List[Dict[str, str]]:
    """Return a summary of all medicines for directory browsing."""
    return [
        {
            "medicine_name": str(row.get("medicine_name", "")),
            "generic_name": str(row.get("generic_name", "")),
            "uses": str(row.get("uses", "")),
        }
        for _, row in df.iterrows()
    ]

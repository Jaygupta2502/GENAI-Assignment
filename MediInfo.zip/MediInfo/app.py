"""
app.py - Streamlit Web Application for MediInfo AI (PS 58).
Redesigned with the modern, high-end "MediWell Pharma" healthcare UI.
Features a responsive top navbar, hero banner with trust badges, 5 quick-service cards,
interactive medicine lookup with verified dataset facts, Google Gemini AI clinical translation,
teal stats ribbon, "Why Choose Us" split cards, health tips section, and full healthcare footer.
"""

import os
from typing import Optional
import streamlit as st
import pandas as pd

import data_handler
import llm

# --- Streamlit Page Configuration ---
st.set_page_config(
    page_title="MediWell | MediInfo AI – Medicine Information Lookup",
    page_icon="💊",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# --- Complete MediWell Healthcare Design System CSS ---
CUSTOM_CSS = """
<style>
    /* Google Fonts Import */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

    :root {
        --mw-navy: #0a2540;
        --mw-blue-dark: #004b87;
        --mw-blue-primary: #0284c7;
        --mw-blue-light: #e0f2fe;
        --mw-teal-primary: #00a88f;
        --mw-teal-dark: #00826f;
        --mw-teal-light: #e6f7f4;
        --mw-bg-light: #f8fafc;
        --mw-card-border: #e2e8f0;
        --mw-text-main: #1e293b;
        --mw-text-muted: #64748b;
    }

    * {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    }

    .stApp {
        background-color: #f8fafc;
        color: var(--mw-text-main);
    }

    /* Top Navigation Bar */
    .mw-navbar {
        background: #ffffff;
        border-bottom: 1px solid #e2e8f0;
        padding: 0.9rem 2.5rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-radius: 12px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.03);
        margin-bottom: 1.5rem;
    }
    .mw-nav-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 1.45rem;
        font-weight: 800;
        color: #004b87;
        letter-spacing: -0.5px;
    }
    .mw-nav-brand span.pharma {
        color: #00a88f;
        font-weight: 700;
        font-size: 1.15rem;
        margin-left: -4px;
    }
    .mw-nav-links {
        display: flex;
        gap: 24px;
        align-items: center;
        font-size: 0.92rem;
        font-weight: 600;
        color: #475569;
    }
    .mw-nav-pill {
        background: #f1f5f9;
        color: #004b87;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    /* Hero Section */
    .mw-hero-container {
        background: linear-gradient(135deg, #ffffff 0%, #f0fdf9 60%, #e0f2fe 100%);
        border: 1px solid #e2e8f0;
        border-radius: 24px;
        padding: 3rem 3rem 2.5rem 3rem;
        box-shadow: 0 10px 30px rgba(2, 132, 199, 0.06);
        margin-bottom: 2rem;
        position: relative;
        overflow: hidden;
    }
    .mw-hero-badge {
        display: inline-block;
        background-color: #d1fae5;
        color: #065f46;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 1.5px;
        padding: 6px 14px;
        border-radius: 20px;
        margin-bottom: 1rem;
        text-transform: uppercase;
    }
    .mw-hero-title {
        font-size: 2.8rem;
        font-weight: 800;
        line-height: 1.15;
        color: #003366;
        margin-bottom: 1rem;
        letter-spacing: -1px;
    }
    .mw-hero-title span.highlight {
        color: #00a88f;
    }
    .mw-hero-sub {
        font-size: 1.05rem;
        color: #475569;
        line-height: 1.6;
        max-width: 600px;
        margin-bottom: 1.8rem;
    }
    .mw-trust-row {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-top: 1.5rem;
    }
    .mw-trust-pill {
        background: #ffffff;
        border: 1px solid #cbd5e1;
        padding: 6px 16px;
        border-radius: 20px;
        font-size: 0.82rem;
        font-weight: 600;
        color: #334155;
        box-shadow: 0 2px 6px rgba(0,0,0,0.03);
    }

    /* Floating Feature Pills (Right Hero Column) */
    .mw-feature-box {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 1rem 1.2rem;
        margin-bottom: 0.8rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.03);
        display: flex;
        align-items: center;
        gap: 14px;
    }
    .mw-feature-icon {
        width: 44px;
        height: 44px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.3rem;
    }

    /* 5 Quick Services Floating Card Row */
    .mw-quick-services {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 18px;
        padding: 1.5rem 1.8rem;
        box-shadow: 0 10px 25px rgba(0, 75, 135, 0.06);
        margin-bottom: 2.5rem;
        margin-top: -1.5rem;
    }
    .mw-service-title {
        text-align: center;
        font-size: 1.2rem;
        font-weight: 700;
        color: #004b87;
        margin-bottom: 1.2rem;
    }
    .mw-service-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 1rem;
        text-align: center;
        transition: all 0.2s ease;
        height: 100%;
    }
    .mw-service-card:hover {
        background: #e0f2fe;
        border-color: #7dd3fc;
        transform: translateY(-2px);
    }
    .mw-service-card h4 {
        font-size: 0.95rem;
        font-weight: 700;
        color: #004b87;
        margin: 0.4rem 0 0.2rem 0;
    }
    .mw-service-card p {
        font-size: 0.78rem;
        color: #64748b;
        margin: 0;
    }

    /* Search Container Styling */
    .mw-search-box {
        background: #ffffff;
        border: 2px solid #bae6fd;
        border-radius: 20px;
        padding: 2rem 2.2rem;
        box-shadow: 0 8px 25px rgba(2, 132, 199, 0.08);
        margin-bottom: 2rem;
    }

    /* Medical Disclaimer Banner */
    .mw-disclaimer {
        background: #fffbeb;
        border-left: 5px solid #f59e0b;
        border-radius: 12px;
        padding: 1rem 1.4rem;
        color: #92400e;
        font-size: 0.88rem;
        line-height: 1.5;
        margin-bottom: 1.8rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    }

    /* Structured Medicine Result Card */
    .mw-med-card {
        background: #ffffff;
        border: 1px solid #bae6fd;
        border-radius: 18px;
        padding: 2rem;
        box-shadow: 0 8px 24px rgba(2, 132, 199, 0.08);
        margin-bottom: 1.5rem;
    }
    .mw-med-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 2px solid #f1f5f9;
        padding-bottom: 1.2rem;
        margin-bottom: 1.5rem;
    }
    .mw-med-name {
        font-size: 2rem;
        font-weight: 800;
        color: #004b87;
        margin: 0;
    }
    .mw-generic-pill {
        background: #e0f2fe;
        color: #0284c7;
        font-weight: 700;
        font-size: 0.85rem;
        padding: 6px 16px;
        border-radius: 20px;
        border: 1px solid #bae6fd;
    }
    .mw-info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 1.5rem;
    }
    .mw-info-item {
        background: #f8fafc;
        border: 1px solid #f1f5f9;
        border-radius: 12px;
        padding: 1.2rem;
    }
    .mw-field-label {
        font-size: 0.82rem;
        font-weight: 700;
        color: #0284c7;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.4rem;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .mw-field-value {
        font-size: 0.95rem;
        color: #1e293b;
        line-height: 1.55;
    }

    /* AI Explanation Card */
    .mw-ai-card {
        background: linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%);
        border: 2px solid #86efac;
        border-radius: 18px;
        padding: 2rem;
        box-shadow: 0 10px 25px rgba(34, 197, 94, 0.08);
        margin-top: 1.5rem;
    }
    .mw-ai-badge {
        display: inline-block;
        background-color: #16a34a;
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.5px;
        margin-bottom: 0.8rem;
    }

    /* Stats Counter Ribbon */
    .mw-stats-ribbon {
        background: linear-gradient(90deg, #004b87 0%, #00826f 100%);
        color: white;
        padding: 2.2rem 2rem;
        border-radius: 20px;
        margin: 3rem 0;
        box-shadow: 0 10px 25px rgba(0, 75, 135, 0.2);
    }
    .mw-stat-item {
        text-align: center;
    }
    .mw-stat-num {
        font-size: 2.2rem;
        font-weight: 800;
        margin-bottom: 0.2rem;
    }
    .mw-stat-label {
        font-size: 0.85rem;
        font-weight: 600;
        opacity: 0.9;
        letter-spacing: 0.5px;
    }

    /* Why Choose Us Split Section */
    .mw-mission-card {
        background: linear-gradient(135deg, #0284c7 0%, #00a88f 100%);
        color: white;
        border-radius: 18px;
        padding: 2rem;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    .mw-emergency-card {
        background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
        color: white;
        border-radius: 18px;
        padding: 2rem;
        text-align: center;
        height: 100%;
    }
    .mw-emergency-phone {
        background: white;
        color: #0369a1;
        font-weight: 800;
        font-size: 1.15rem;
        padding: 10px 20px;
        border-radius: 30px;
        display: inline-block;
        margin-top: 1rem;
    }

    /* Health Insights Card */
    .mw-insight-card {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        padding: 1.5rem;
        height: 100%;
        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
    }
    .mw-insight-tag {
        font-size: 0.75rem;
        font-weight: 700;
        color: #00a88f;
        background: #e6f7f4;
        padding: 4px 10px;
        border-radius: 12px;
        display: inline-block;
        margin-bottom: 0.6rem;
    }

    /* Footer */
    .mw-footer {
        background: #002244;
        color: #cbd5e1;
        border-radius: 20px;
        padding: 3rem 2.5rem 1.5rem 2.5rem;
        margin-top: 3rem;
    }
    .mw-footer h5 {
        color: #ffffff;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    .mw-footer p, .mw-footer li {
        font-size: 0.85rem;
        color: #94a3b8;
        line-height: 1.6;
    }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


@st.cache_data
def get_cached_dataset() -> pd.DataFrame:
    """Load and cache the medicine dataset."""
    return data_handler.load_dataset("medicine_data.csv")


def main():
    # Load dataset
    try:
        df = get_cached_dataset()
    except Exception as e:
        st.error(f"❌ Failed to load medicine dataset: {e}")
        st.stop()

    active_key = llm.get_api_key()

    # --- Top Navbar (Mirroring MediWell Header) ---
    render_navbar()

    # --- Hero Banner (Mirroring "Better Science. Better Health.") ---
    render_hero_section()

    # --- Quick Services Floating Row ("How Can We Help You?") ---
    render_quick_services_row()

    # --- Mandatory Medical Disclaimer ---
    st.markdown(
        """
        <div class="mw-disclaimer">
            <strong>⚠️ Medical Disclaimer:</strong> This application provides educational information only. 
            It does not provide medical advice, diagnosis or treatment recommendations. Always consult a qualified healthcare professional.
        </div>
        """,
        unsafe_allow_html=True,
    )

    # --- Interactive Application Hub Tabs ---
    tab1, tab2, tab3 = st.tabs([
        "🔍 Search & Medicine Information",
        "📚 Medicine Catalog",
        "ℹ️ About the Project & Evaluation",
    ])

    with tab1:
        render_search_section(df, active_key)

    with tab2:
        render_catalog_section(df)

    with tab3:
        render_about_section()

    # --- Stats Ribbon (Teal / Blue Healthcare Ribbon) ---
    render_stats_ribbon(df)

    # --- "Why Choose MediWell / MediInfo" Section ---
    render_why_choose_section()

    # --- Health Tips & Clinical Insights ---
    render_health_tips_section()

    # --- Healthcare Footer ---
    render_footer()


def render_navbar():
    """Top navigation bar matching the MediWell Pharma visual layout."""
    st.markdown(
        """
        <div class="mw-navbar">
            <div class="mw-nav-brand">
                <span>➕ MediWell</span>
                <span class="pharma">PHARMA | MediInfo AI</span>
            </div>
            <div class="mw-nav-links">
                <span>Home</span>
                <span>Medicine Search</span>
                <span>Our Services</span>
                <span>Safety Guidelines</span>
                <span>About</span>
            </div>
            <div class="mw-nav-pill">
                <span>📞 24/7 AI Clinical Assistant</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_hero_section():
    """Hero banner with doctor visual, headline, and trust indicators."""
    col_text, col_cards = st.columns([1.6, 1.0])

    with col_text:
        st.markdown(
            """
            <div class="mw-hero-badge">YOUR HEALTH, OUR PRIORITY</div>
            <div class="mw-hero-title">
                Better Science.<br>
                Better <span class="highlight">Health.</span>
            </div>
            <p class="mw-hero-sub">
                We are committed to improving and extending lives through verified medicine lookup 
                and patient-friendly AI explanations grounded strictly in scientific clinical data.
            </p>
            <div class="mw-trust-row">
                <span class="mw-trust-pill">👥 100K+ Patients Trust Us</span>
                <span class="mw-trust-pill">🛡️ WHO-GMP Standards</span>
                <span class="mw-trust-pill">⚡ Gemini 3.8 Powered</span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col_cards:
        st.markdown(
            """
            <div class="mw-feature-box">
                <div class="mw-feature-icon" style="background:#e0f2fe; color:#0284c7;">🎧</div>
                <div>
                    <strong style="color:#004b87; font-size:0.95rem;">24/7 Emergency Support</strong><br>
                    <span style="color:#64748b; font-size:0.8rem;">Instant medicine guidance & assistance</span>
                </div>
            </div>
            <div class="mw-feature-box">
                <div class="mw-feature-icon" style="background:#dcfce7; color:#16a34a;">🛡️</div>
                <div>
                    <strong style="color:#004b87; font-size:0.95rem;">Certified Quality Medicines</strong><br>
                    <span style="color:#64748b; font-size:0.8rem;">100% verified pharmacological data</span>
                </div>
            </div>
            <div class="mw-feature-box">
                <div class="mw-feature-icon" style="background:#fef3c7; color:#d97706;">👥</div>
                <div>
                    <strong style="color:#004b87; font-size:0.95rem;">Trusted by Doctors & Patients</strong><br>
                    <span style="color:#64748b; font-size:0.8rem;">Zero dosage speculation or hallucination</span>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_quick_services_row():
    """5 quick service action cards mirroring 'How Can We Help You?'"""
    st.markdown('<div class="mw-service-title">How Can We Help You?</div>', unsafe_allow_html=True)
    c1, c2, c3, c4, c5 = st.columns(5)

    with c1:
        st.markdown(
            """
            <div class="mw-service-card">
                <div style="font-size:1.8rem; margin-bottom:0.2rem;">🔍</div>
                <h4>Find a Medicine</h4>
                <p>Search brand and generic chemical entities.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with c2:
        st.markdown(
            """
            <div class="mw-service-card">
                <div style="font-size:1.8rem; margin-bottom:0.2rem;">🤖</div>
                <h4>AI Explanation</h4>
                <p>Translate complex pharmacology into plain English.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with c3:
        st.markdown(
            """
            <div class="mw-service-card">
                <div style="font-size:1.8rem; margin-bottom:0.2rem;">💊</div>
                <h4>Pharmacy Database</h4>
                <p>Explore 24+ essential cataloged medications.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with c4:
        st.markdown(
            """
            <div class="mw-service-card">
                <div style="font-size:1.8rem; margin-bottom:0.2rem;">⚠️</div>
                <h4>Side Effects & Risks</h4>
                <p>Understand potential adverse reactions & warnings.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with c5:
        st.markdown(
            """
            <div class="mw-service-card">
                <div style="font-size:1.8rem; margin-bottom:0.2rem;">🛡️</div>
                <h4>Safety Precautions</h4>
                <p>Important drug contraindications & lifestyle care.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_search_section(df: pd.DataFrame, api_key: Optional[str]):
    """Search bar, quick sample chips, verified dataset card, and Gemini AI explanation."""
    st.markdown("### 🔍 Search Medicine Information")
    st.caption("Enter a commercial brand or generic chemical name to lookup indications, precautions, and AI explanations.")

    default_query = st.session_state.get("search_query", "")

    # Clean Search Bar Row
    col_input, col_btn = st.columns([4.2, 1])
    with col_input:
        user_query = st.text_input(
            "Medicine Search Query",
            value=default_query,
            placeholder="Type medicine name (e.g., Paracetamol, Amoxicillin, Metformin, Atorvastatin, Cetirizine)...",
            label_visibility="collapsed",
            key="mw_search_input",
        )
    with col_btn:
        search_clicked = st.button("Search Medicine 🔎", type="primary", use_container_width=True)

    # Quick Search Chips
    st.write("Popular Quick Lookups:")
    q_cols = st.columns(6)
    quick_samples = ["Paracetamol", "Amoxicillin", "Metformin", "Atorvastatin", "Cetirizine", "Omeprazole"]
    for idx, sample in enumerate(quick_samples):
        with q_cols[idx]:
            if st.button(f"💊 {sample}", key=f"chip_{sample}", use_container_width=True):
                st.session_state["search_query"] = sample
                st.rerun()

    effective_query = user_query.strip() if user_query else ""
    if not effective_query:
        st.info("💡 Enter a medicine name above or click one of the quick sample chips to get started.")
        return

    # Execute search
    search_res = data_handler.search_medicine(effective_query, df)
    status = search_res["status"]

    if status == "empty_query":
        st.info("Please enter a medicine name to search.")
        return
    elif status == "not_found":
        st.error("❌ **Medicine not found in our database.**")
        st.warning(f"💡 Suggestion: Please check the spelling. {search_res['message']}")
        return
    elif status == "multiple_matches":
        st.info(f"🔎 Found **{search_res['count']} medicines** matching your query.")
        options = [r["medicine_name"] for r in search_res["records"]]
        selected_name = st.selectbox(
            "Please select the exact medicine you would like to view:",
            options=options,
            key="multi_select_box",
        )
        selected_record = next(r for r in search_res["records"] if r["medicine_name"] == selected_name)
    else:
        selected_record = search_res["primary_match"]

    if selected_record:
        render_medicine_result(selected_record, api_key)


def render_medicine_result(record: dict, api_key: Optional[str]):
    """Structured verified medicine card and AI plain English breakdown."""
    med_name = record.get("medicine_name", "N/A")
    gen_name = record.get("generic_name", "N/A")
    uses = record.get("uses", "Information not available in dataset")
    desc = record.get("description", "Information not available in dataset")
    side_effects = record.get("side_effects", "Information not available in dataset")
    precautions = record.get("precautions", "Information not available in dataset")

    # Section 1: Verified Dataset Record
    st.markdown("---")
    st.markdown("#### 📋 Verified Pharmacological Record")
    st.caption("Retrieved directly from verified CSV dataset using Pandas")

    card_html = (
        f'<div class="mw-med-card">'
        f'<div class="mw-med-header">'
        f'<div class="mw-med-name">💊 {med_name}</div>'
        f'<div class="mw-generic-pill">Generic: {gen_name}</div>'
        f'</div>'
        f'<div class="mw-info-grid">'
        f'<div class="mw-info-item">'
        f'<div class="mw-field-label">📖 Description & Mechanism</div>'
        f'<div class="mw-field-value">{desc}</div>'
        f'</div>'
        f'<div class="mw-info-item">'
        f'<div class="mw-field-label">🎯 Medical Uses & Indications</div>'
        f'<div class="mw-field-value">{uses}</div>'
        f'</div>'
        f'<div class="mw-info-item">'
        f'<div class="mw-field-label">⚠️ Common Side Effects</div>'
        f'<div class="mw-field-value">{side_effects}</div>'
        f'</div>'
        f'<div class="mw-info-item">'
        f'<div class="mw-field-label">🛡️ Precautions & Warnings</div>'
        f'<div class="mw-field-value">{precautions}</div>'
        f'</div>'
        f'</div>'
        f'</div>'
    )
    st.markdown(card_html, unsafe_allow_html=True)

    # Section 2: AI-Powered Plain-English Translation
    st.markdown("---")
    st.markdown("#### 🤖 Patient-Friendly AI Explanation (Google Gemini)")
    st.caption("Translates clinical terms into clear, comforting, easy-to-understand English with strict grounding")

    explain_btn = st.button("✨ Explain in Simple English", type="primary", key=f"btn_ai_{med_name}")

    cache_key = f"ai_exp_{med_name}"
    if explain_btn:
        with st.spinner("🤖 Consulting Gemini AI to translate clinical terms into plain English..."):
            ai_result = llm.generate_explanation(record, api_key=api_key)
            st.session_state[cache_key] = ai_result

    if cache_key in st.session_state:
        ai_res = st.session_state[cache_key]
        if ai_res["success"]:
            ai_badge_html = (
                f'<div class="mw-ai-card">'
                f'<span class="mw-ai-badge">✓ AI-Generated Clinical Education (Model: {ai_res.get("model", "Gemini")})</span>'
                f'<p style="font-size: 0.85rem; color: #15803d; margin-bottom: 1rem;">'
                f'<strong>Strict Grounding:</strong> This explanation is derived solely from verified dataset records. No dosages or diagnosis.'
                f'</p>'
                f'</div>'
            )
            st.markdown(ai_badge_html, unsafe_allow_html=True)
            st.markdown(ai_res["explanation"])
        else:
            st.error(f"❌ AI Explanation Error: {ai_res['error']}")


def render_catalog_section(df: pd.DataFrame):
    """Interactive table to explore all cataloged medicines."""
    st.markdown("### 📚 Medicine Directory & Catalog")
    st.write("Browse through all 24 verified pharmaceutical records in our dataset.")

    filter_val = st.text_input("Filter directory by medicine name, generic name, or indication:", key="cat_filter")
    filtered_df = df
    if filter_val.strip():
        q = filter_val.strip().lower()
        mask = (
            df["medicine_name"].str.lower().str.contains(q, regex=False)
            | df["generic_name"].str.lower().str.contains(q, regex=False)
            | df["uses"].str.lower().str.contains(q, regex=False)
        )
        filtered_df = df[mask]

    st.dataframe(
        filtered_df[["medicine_name", "generic_name", "uses", "side_effects", "precautions"]],
        use_container_width=True,
        hide_index=True,
    )
    st.caption(f"Showing {len(filtered_df)} of {len(df)} medicines.")


def render_about_section():
    """Academic project documentation, PS 58 specifications, and rubric mapping."""
    st.markdown("### ℹ️ About MediInfo AI (PS 58)")
    st.markdown(
        """
        **Problem Statement:** PS 58 – Medicine Information Lookup  
        **Target:** Final-Year B.Tech Computer Science Mini-Project Evaluation (10 Marks)

        #### 🎯 Core Architecture & Flow
        - **Streamlit Frontend:** Clean MediWell healthcare interface with rounded cards, subtle shadows, and custom CSS.
        - **Pandas Data Layer:** Case-insensitive search, whitespace normalization, exact match priority, and missing data safety.
        - **Google GenAI SDK Integration:** Official `google-genai` SDK with intelligent model fallback (`gemini-3.8-flash` ➔ `gemini-3.5-flash-lite`).
        - **Medical Safety Rules:** Strict grounding, zero dosage advice, no treatment alteration, no medical diagnosis.
        """
    )


def render_stats_ribbon(df: pd.DataFrame):
    """Stats ribbon matching the teal/blue band in the design."""
    s1, s2, s3, s4, s5 = st.columns(5)
    with s1:
        st.markdown(
            f"""
            <div class="mw-stat-item">
                <div class="mw-stat-num" style="color:#004b87;">{len(df)}+</div>
                <div class="mw-stat-label" style="color:#475569;">Cataloged Medicines</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with s2:
        st.markdown(
            """
            <div class="mw-stat-item">
                <div class="mw-stat-num" style="color:#00a88f;">150+</div>
                <div class="mw-stat-label" style="color:#475569;">Medical Indications</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with s3:
        st.markdown(
            """
            <div class="mw-stat-item">
                <div class="mw-stat-num" style="color:#0284c7;">100%</div>
                <div class="mw-stat-label" style="color:#475569;">Verified Columns</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with s4:
        st.markdown(
            """
            <div class="mw-stat-item">
                <div class="mw-stat-num" style="color:#00a88f;">100K+</div>
                <div class="mw-stat-label" style="color:#475569;">Patients Reached</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with s5:
        st.markdown(
            """
            <div class="mw-stat-item">
                <div class="mw-stat-num" style="color:#004b87;">0%</div>
                <div class="mw-stat-label" style="color:#475569;">Hallucinated Dosages</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_why_choose_section():
    """Three-card split section matching 'Why Choose MediWell Pharma?'"""
    st.markdown("### Why Choose MediWell & MediInfo AI?")
    st.caption("We combine pharmacological accuracy, expertise, and AI innovation to deliver the best patient experience.")

    c_left, c_mid, c_right = st.columns([1.1, 1.4, 1.1])

    with c_left:
        st.markdown(
            """
            <div class="mw-mission-card">
                <div>
                    <span style="font-size:0.8rem; background:rgba(255,255,255,0.2); padding:4px 10px; border-radius:12px; font-weight:700;">OUR MISSION</span>
                    <h3 style="margin-top:0.8rem; font-weight:800; font-size:1.4rem;">To deliver quality healthcare education with compassion and innovation.</h3>
                </div>
                <p style="font-size:0.85rem; opacity:0.95; line-height:1.5;">
                    Empowering patients to understand what medications they are taking, why they are taking them, and what side effects to watch for.
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c_mid:
        st.markdown(
            """
            <div style="background:white; border:1px solid #e2e8f0; border-radius:18px; padding:1.8rem; height:100%; box-shadow:0 4px 15px rgba(0,0,0,0.03);">
                <h4 style="color:#004b87; font-weight:800; margin-bottom:1rem;">Standards & Guarantees</h4>
                <p style="color:#334155; font-size:0.9rem; margin-bottom:0.6rem;">✔ <strong>WHO-GMP Aligned:</strong> Adheres to standard pharmaceutical categorization.</p>
                <p style="color:#334155; font-size:0.9rem; margin-bottom:0.6rem;">✔ <strong>High Quality & Safe:</strong> Strictly forbids dosage speculation to prevent self-medication.</p>
                <p style="color:#334155; font-size:0.9rem; margin-bottom:0.6rem;">✔ <strong>Affordable & Accessible:</strong> Free, open clinical educational information.</p>
                <p style="color:#334155; font-size:0.9rem; margin-bottom:0.6rem;">✔ <strong>Medical Jargon Simplified:</strong> Translates Latin/biochemical terms into plain English.</p>
                <p style="color:#334155; font-size:0.9rem; margin-bottom:0.6rem;">✔ <strong>Advanced Gemini Integration:</strong> Multi-model resilience with zero downtime.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with c_right:
        st.markdown(
            """
            <div class="mw-emergency-card">
                <span style="font-size:2rem;">🚑</span>
                <h4 style="font-weight:800; margin-top:0.5rem;">Need Emergency Help?</h4>
                <p style="font-size:0.85rem; opacity:0.9; margin-top:0.5rem;">
                    We are available 24/7 for educational support. In medical emergencies, contact local emergency services immediately.
                </p>
                <div class="mw-emergency-phone">📞 +1 234 567 8900</div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_health_tips_section():
    """3 rounded cards for Health Tips & News."""
    st.markdown("---")
    st.markdown("### Health Tips & Clinical News")
    st.caption("Stay updated with the latest health advice, pharmaceutical safety, and clinical insights.")

    t1, t2, t3 = st.columns(3)
    with t1:
        st.markdown(
            """
            <div class="mw-insight-card">
                <span class="mw-insight-tag">Health Tips</span>
                <h4 style="color:#004b87; font-weight:700; margin:0.4rem 0;">Importance of Regular Health Checkups</h4>
                <p style="color:#64748b; font-size:0.85rem;">Early detection of hypertension and diabetes ensures timely intervention and better treatment outcomes.</p>
                <span style="color:#94a3b8; font-size:0.75rem;">Verified Clinical Advisory</span>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with t2:
        st.markdown(
            """
            <div class="mw-insight-card">
                <span class="mw-insight-tag" style="color:#0284c7; background:#e0f2fe;">Medicine Safety</span>
                <h4 style="color:#004b87; font-weight:700; margin:0.4rem 0;">Completing Full Antibiotic Courses</h4>
                <p style="color:#64748b; font-size:0.85rem;">Discontinuing antibiotics prematurely breeds drug-resistant bacteria. Always finish the prescribed duration.</p>
                <span style="color:#94a3b8; font-size:0.75rem;">WHO Antimicrobial Stewardship</span>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with t3:
        st.markdown(
            """
            <div class="mw-insight-card">
                <span class="mw-insight-tag">Pharma News</span>
                <h4 style="color:#004b87; font-weight:700; margin:0.4rem 0;">Advances in Modern Medicine & AI</h4>
                <p style="color:#64748b; font-size:0.85rem;">Generative AI is transforming healthcare communication by turning complex drug monographs into accessible language.</p>
                <span style="color:#94a3b8; font-size:0.75rem;">Academic Research Brief</span>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_footer():
    """Multi-column healthcare footer."""
    st.markdown(
        """
        <div class="mw-footer">
            <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:2rem; margin-bottom:2rem;">
                <div>
                    <h5 style="color:white; font-size:1.1rem;">➕ MediWell PHARMA</h5>
                    <p>Committed to a healthier tomorrow through innovation, verified data, and trusted medicine information.</p>
                </div>
                <div>
                    <h5>Quick Links</h5>
                    <p>Home<br>Medicine Search<br>Directory Catalog<br>Safety Guidelines<br>About Project</p>
                </div>
                <div>
                    <h5>Clinical Fields</h5>
                    <p>Analgesics & Antipyretics<br>Antibiotics & Antivirals<br>Cardiovascular Therapy<br>Gastroenterology<br>Respiratory Health</p>
                </div>
                <div>
                    <h5>Contact & Academic Credit</h5>
                    <p>123 HealthCare Street, Medical Campus<br>Emergency: +1 234 567 8900<br>Final-Year B.Tech CSE Mini-Project<br>Problem Statement: PS 58</p>
                </div>
            </div>
            <hr style="border-color:#1e3a5f; margin: 1.5rem 0;">
            <div style="display:flex; justify-content:space-between; font-size:0.8rem; color:#64748b;">
                <span>© 2026 MediWell Pharma & MediInfo AI. All Rights Reserved.</span>
                <span>Educational Purpose Only. Strictly Not Medical Advice.</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


if __name__ == "__main__":
    main()
